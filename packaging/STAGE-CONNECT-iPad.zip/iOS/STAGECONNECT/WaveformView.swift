// WaveformView.swift
// Forma de onda horizontal: amplitud simétrica, color por frecuencia
// (graves rojo/naranja, medios amarillo/verde, agudos azul), playhead
// vertical y scroll subpíxel sincronizado con la reproducción.

import SwiftUI

enum WaveformMode {
    /// Ventana que se desplaza; playhead fijo al centro (vista Grande / MASTER).
    case scrolling
    /// Toda la pista; playhead en la fracción de progreso (vista Pequeña).
    case overview
}

struct WaveformView: View {
    let progress:    Double?
    let trackLength: Double?
    let bpm:         Double
    let beatInBar:   Int
    let isPlaying:   Bool
    let accent:      Color
    let trackSeed:   Int
    var peaks:       [UInt8] = []
    var cuePositionFraction: Double? = nil
    var loopInFraction:  Double? = nil
    var loopOutFraction: Double? = nil
    var mode: WaveformMode = .scrolling
    /// Ventana visible en segundos. CDJ ~12 s.
    var windowSeconds: Double = 12.0

    var body: some View {
        Canvas { ctx, size in
            ctx.fill(Path(CGRect(origin: .zero, size: size)), with: .color(Color.black))
            let midY = size.height / 2
            ctx.fill(
                Path(CGRect(x: 0, y: midY - 0.5, width: size.width, height: 1)),
                with: .color(Color.white.opacity(0.18))
            )
            if mode == .overview {
                drawOverview(ctx: ctx, size: size)
            } else {
                drawScrolling(ctx: ctx, size: size)
            }
        }
        .transaction { $0.animation = nil }
        .frame(minHeight: 36)
        .background(Color.black)
    }

    // MARK: - Tiempo real de la pista

    private var elapsedSeconds: Double {
        if let p = progress, let l = trackLength, l > 0, p.isFinite, l.isFinite {
            return min(max(p, 0), 1) * l
        }
        return 0
    }

    private var durationSeconds: Double {
        let l = trackLength ?? 0
        return l > 0 && l.isFinite ? l : 0
    }

    private var hasTimeline: Bool { durationSeconds > 0 && progress != nil }

    // MARK: - Scrolling: playhead al centro, scroll subpíxel

    private func drawScrolling(ctx: GraphicsContext, size: CGSize) {
        let cols = max(90, Int(size.width / 2.6))
        let colW = size.width / CGFloat(cols)
        let midX = size.width / 2
        let elapsed = elapsedSeconds
        let duration = durationSeconds
        let secPerCol = windowSeconds / Double(cols)
        let exact = elapsed / secPerCol
        let frac = exact - floor(exact)
        let shift = CGFloat(frac) * colW

        drawLoopScrolling(ctx: ctx, size: size, elapsed: elapsed, secPerCol: secPerCol, shift: shift, colW: colW, cols: cols)

        for i in 0...cols {
            let offset = Double(i) - Double(cols) / 2
            let t = elapsed + (offset - frac) * secPerCol
            let x = CGFloat(i) * colW - shift
            guard x > -colW && x < size.width + colW else { continue }

            drawBeatGridLine(ctx: ctx, x: x, size: size, time: t, secPerCol: secPerCol)

            let inTrack = hasTimeline && t >= -0.02 && t <= duration + 0.02
            let isPast = t < elapsed
            let fade: Double = inTrack ? (isPast ? 1.0 : 0.78) : 0.16
            drawColumn(ctx: ctx, x: x, colW: colW, size: size, time: t, fade: fade)
        }

        drawPlayhead(ctx: ctx, x: midX, size: size)
        drawCueScrolling(ctx: ctx, size: size, elapsed: elapsed, secPerCol: secPerCol, shift: shift, colW: colW, cols: cols)
    }

    // MARK: - Overview (pista completa)

    private func drawOverview(ctx: GraphicsContext, size: CGSize) {
        let cols = max(90, Int(size.width / 2.6))
        let colW = size.width / CGFloat(cols)
        let duration = durationSeconds
        let prog = hasTimeline ? min(max(progress ?? 0, 0), 1) : 0
        let playX = CGFloat(prog) * size.width

        if let loopIn = loopInFraction, let loopOut = loopOutFraction, loopIn < loopOut {
            let x1 = CGFloat(loopIn) * size.width
            let x2 = CGFloat(loopOut) * size.width
            ctx.fill(Path(CGRect(x: x1, y: 0, width: max(1, x2 - x1), height: size.height)),
                     with: .color(Color.green.opacity(0.16)))
        }

        for i in 0..<cols {
            let frac = (Double(i) + 0.5) / Double(cols)
            let t = duration > 0 ? frac * duration : 0
            let x = CGFloat(i) * colW
            let isPast = hasTimeline && frac < prog
            drawColumn(ctx: ctx, x: x, colW: colW, size: size, time: t, fade: isPast ? 1.0 : 0.72)
        }

        if hasTimeline {
            drawPlayhead(ctx: ctx, x: playX, size: size)
        }
        if let cue = cuePositionFraction {
            strokeMarker(ctx: ctx, x: CGFloat(cue) * size.width, size: size, color: Color.orange)
        }
    }

    // MARK: - Columna de amplitud coloreada por frecuencia

    /// Tres bandas apiladas (grave / medio / agudo) con hueco entre barras.
    private func drawColumn(ctx: GraphicsContext, x: CGFloat, colW: CGFloat, size: CGSize, time t: Double, fade: Double) {
        let midY = size.height / 2
        let maxH = size.height * 0.46
        let (amp, bass, mid, hi) = sampleAt(time: t)
        guard amp > 0.02, fade > 0.05 else { return }
        let gap = max(0.8, colW * 0.28)
        let bw = max(1.2, colW - gap)
        let bx = x + gap * 0.5

        let bassH = CGFloat(bass) * maxH * 0.52
        let midH  = CGFloat(mid)  * maxH * 0.30
        let hiH   = CGFloat(hi)   * maxH * 0.18

        func pair(_ yOff: CGFloat, _ h: CGFloat, _ color: Color) {
            guard h > 0.4 else { return }
            let top = CGRect(x: bx, y: midY - yOff - h, width: bw, height: h)
            let bot = CGRect(x: bx, y: midY + yOff, width: bw, height: h)
            ctx.fill(Path(top), with: .color(color.opacity(fade)))
            ctx.fill(Path(bot), with: .color(color.opacity(fade * 0.88)))
        }

        pair(0, bassH, Theme.wfBass)
        pair(bassH + 0.6, midH, Theme.wfMid)
        pair(bassH + midH + 1.2, hiH, Theme.wfHigh)
    }

    private func sampleAt(time t: Double) -> (amp: Double, bass: Double, mid: Double, hi: Double) {
        let amp: Double
        if !peaks.isEmpty, durationSeconds > 0 {
            amp = Double(peakAt(time: t))
        } else {
            let beat: Double
            if bpm > 20 {
                beat = t * bpm / 60.0
            } else {
                beat = t * 2.0
            }
            amp = bandHeight(beat: beat, seed: trackSeed)
        }
        if durationSeconds > 0 && (t < 0 || t > durationSeconds) {
            return (amp * 0.10, 0, 0, 0)
        }
        let (bass, mid, hi) = spectrum(amp: amp, time: t)
        return (amp, bass, mid, hi)
    }

    private func peakAt(time t: Double) -> Float {
        let n = peaks.count
        guard n > 1, durationSeconds > 0 else {
            return n == 0 ? 0 : Float(peaks[0]) / 255.0
        }
        if t < 0 || t > durationSeconds { return 0 }
        let x = (t / durationSeconds) * Double(n - 1)
        return interpPeak(x)
    }

    private func interpPeak(_ x: Double) -> Float {
        let n = peaks.count
        guard n > 0 else { return 0 }
        if x < 0 || x > Double(n - 1) { return 0 }
        let i = min(n - 1, max(0, Int(x)))
        let j = min(n - 1, i + 1)
        let ft = Float(x - Double(i))
        let a = Float(peaks[i]) / 255.0
        let b = Float(peaks[j]) / 255.0
        return a + (b - a) * ft
    }

    /// Graves lentos, medios y agudos más rápidos — pinta el color, no apila bandas.
    private func spectrum(amp a: Double, time t: Double) -> (Double, Double, Double) {
        let g = max(0, min(1, a))
        guard g > 0.005 else { return (0, 0, 0) }
        let s = Double(abs(trackSeed % 997) + 1)

        let bassOsc = sin(t * 0.13 + s * 0.013) * 0.42 +
                      sin(t * 0.37 + s * 0.029) * 0.23
        let midOsc  = sin(t * 0.23 + s * 0.023 + 4.71) * 0.35 +
                      sin(t * 0.61 + s * 0.031 + 1.90) * 0.20
        let hiOsc   = sin(t * 0.47 + s * 0.019 + 2.10) * 0.38 +
                      sin(t * 1.31 + s * 0.011 + 3.70) * 0.22 +
                      sin(t * 3.17 + s * 0.037 + 1.20) * 0.10

        let bass = max(0.08, min(1.0, bassOsc + 0.72)) * g
        let mid  = max(0.03, min(1.0, midOsc  + 0.62)) * g
        let hi   = max(0.03, min(1.0, hiOsc   + 0.58)) * g
        return (bass, mid, hi)
    }

    private func drawBeatGridLine(ctx: GraphicsContext, x: CGFloat, size: CGSize, time t: Double, secPerCol: Double) {
        guard bpm > 20, t >= 0 else { return }
        let beat = t * bpm / 60.0
        let beatMod = beat.truncatingRemainder(dividingBy: 1.0)
        let wrapped = beatMod < 0 ? beatMod + 1 : beatMod
        let beatWidth = secPerCol * bpm / 60.0
        let slop = max(0.06, min(0.22, beatWidth * 0.45))
        guard wrapped < slop || wrapped > (1 - slop) else { return }
        let barMod = beat.truncatingRemainder(dividingBy: 4.0)
        let barWrapped = barMod < 0 ? barMod + 4 : barMod
        let isDownbeat = barWrapped < slop || barWrapped > (4 - slop)
        guard isDownbeat else { return }
        let isCurrent = beatInBar > 0 && Int(barWrapped) + 1 == beatInBar
        ctx.fill(
            Path(CGRect(x: x, y: 0, width: 1, height: size.height)),
            with: .color(Color.white.opacity(isCurrent ? 0.55 : 0.22))
        )
    }

    private func drawPlayhead(ctx: GraphicsContext, x: CGFloat, size: CGSize) {
        var glow = Path()
        glow.move(to: CGPoint(x: x, y: 0))
        glow.addLine(to: CGPoint(x: x, y: size.height))
        ctx.stroke(glow, with: .color(.white.opacity(0.22)), lineWidth: 5)

        var ph = Path()
        ph.move(to: CGPoint(x: x, y: 0))
        ph.addLine(to: CGPoint(x: x, y: size.height))
        ctx.stroke(ph, with: .color(.white.opacity(isPlaying ? 0.98 : 0.78)), lineWidth: isPlaying ? 1.6 : 1.2)

        let top = Path { p in
            p.move(to: CGPoint(x: x - 5, y: 0))
            p.addLine(to: CGPoint(x: x + 5, y: 0))
            p.addLine(to: CGPoint(x: x, y: 7))
            p.closeSubpath()
        }
        ctx.fill(top, with: .color(.white))

        let bot = Path { p in
            p.move(to: CGPoint(x: x - 5, y: size.height))
            p.addLine(to: CGPoint(x: x + 5, y: size.height))
            p.addLine(to: CGPoint(x: x, y: size.height - 7))
            p.closeSubpath()
        }
        ctx.fill(bot, with: .color(.white))
    }

    private func drawLoopScrolling(ctx: GraphicsContext, size: CGSize, elapsed: Double, secPerCol: Double, shift: CGFloat, colW: CGFloat, cols: Int) {
        guard let loopIn = loopInFraction, let loopOut = loopOutFraction, loopIn < loopOut, durationSeconds > 0 else { return }
        let x1 = xForTime(loopIn * durationSeconds, elapsed: elapsed, secPerCol: secPerCol, shift: shift, colW: colW, cols: cols)
        let x2 = xForTime(loopOut * durationSeconds, elapsed: elapsed, secPerCol: secPerCol, shift: shift, colW: colW, cols: cols)
        if x2 > x1 {
            ctx.fill(Path(CGRect(x: x1, y: 0, width: x2 - x1, height: size.height)),
                     with: .color(Color.green.opacity(0.16)))
            ctx.fill(Path(CGRect(x: x1, y: 0, width: 1.5, height: size.height)),
                     with: .color(Color.green.opacity(0.80)))
            ctx.fill(Path(CGRect(x: x2 - 1.5, y: 0, width: 1.5, height: size.height)),
                     with: .color(Color.green.opacity(0.80)))
        }
    }

    private func drawCueScrolling(ctx: GraphicsContext, size: CGSize, elapsed: Double, secPerCol: Double, shift: CGFloat, colW: CGFloat, cols: Int) {
        guard let cueFrac = cuePositionFraction, durationSeconds > 0 else { return }
        let cx = xForTime(cueFrac * durationSeconds, elapsed: elapsed, secPerCol: secPerCol, shift: shift, colW: colW, cols: cols)
        guard cx >= 0 && cx <= size.width else { return }
        strokeMarker(ctx: ctx, x: cx, size: size, color: Color.orange)
    }

    private func strokeMarker(ctx: GraphicsContext, x: CGFloat, size: CGSize, color: Color) {
        var cp = Path()
        cp.move(to: CGPoint(x: x, y: 0))
        cp.addLine(to: CGPoint(x: x, y: size.height))
        ctx.stroke(cp, with: .color(color.opacity(0.90)), lineWidth: 2)
        let ct = Path { p in
            p.move(to: CGPoint(x: x - 5, y: 0))
            p.addLine(to: CGPoint(x: x + 5, y: 0))
            p.addLine(to: CGPoint(x: x, y: 7))
            p.closeSubpath()
        }
        ctx.fill(ct, with: .color(color))
    }

    private func xForTime(_ t: Double, elapsed: Double, secPerCol: Double, shift: CGFloat, colW: CGFloat, cols: Int) -> CGFloat {
        let offsetCols = (t - elapsed) / secPerCol
        return (CGFloat(cols) / 2 + CGFloat(offsetCols)) * colW - shift
    }

    private func bandHeight(beat: Double, seed: Int) -> Double {
        let s = Double(abs(seed % 997) + 1)
        let a = abs(sin(beat * 0.35 + s * 0.017)) * 0.55
        let b = abs(sin(beat * 0.71 + s * 0.031)) * 0.35
        let c = abs(sin(beat * 0.53 + s * 0.048)) * 0.10
        return min(1.0, max(0.06, a + b + c))
    }
}
